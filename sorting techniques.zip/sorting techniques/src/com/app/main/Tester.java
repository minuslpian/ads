package com.app.main;

import java.util.Scanner;

public class Tester {
	public static int partition(int arr[],int lower,int upper) {
		int i,j,pivot,temp;
		i=lower-1;
		pivot=arr[upper];
		for(j=lower;j<=upper;j++) {
			if(arr[j]<pivot) {
				i=i+1;
				temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
		temp=arr[i+1];
		arr[i+1]=arr[upper];
		arr[upper]=temp;
		return i+1;
	}
	public static void quickSort(int arr[],int lower,int upper) {
		       int q;
		       if(lower<upper) {
		    	   q=partition(arr,lower,upper);
		    	   quickSort(arr,lower,q-1);
		    	   quickSort(arr,q+1,upper);
		       }
		       
	}
	
	public static void insertionSort(int arr []) {
		int i,j,key;
		for(i=1;i<arr.length;i++) {
			key=arr[i];
			for(j=i-1;j>=0;j--) {
				if(key<arr[j]) {
					arr[j+1]=arr[j];
					
				}
				else
					break;
			}
			arr[j+1]=key;
		}
	}
	
	public static void bubbleSort(int []arr) {
		int j,i;
		for(i=0;i<arr.length-1;i++) {
			for(j=0;j<arr.length-i-1;j++) {
				
				if(arr[j]>arr[j+1]) {
					arr[j]=arr[j+1]+arr[j];
					arr[j+1]=arr[j]-arr[j+1];
					arr[j]=arr[j]-arr[j+1];
				}
			}
		}
	}
	public static void selectionSort(int []arr) {
		int j,i;
		for(i=0;i<arr.length-1;i++) {
			for(j=i+1;j<arr.length;j++) {
				if(arr[i]>arr[j]) {
					arr[i]=arr[j]+arr[i];
					arr[j]=arr[i]-arr[j];
					arr[i]=arr[i]-arr[j];
				}
			}
		}
	}
	public static void main(String[] args) {
		try(Scanner sc= new Scanner(System.in)){
			int []arr=new int[5];
			System.out.println("Enter five integers: ");
			for(int i=0;i<arr.length;i++) {
				arr[i]=sc.nextInt();
			}
//			System.out.println("Array elements: ");
//			for(int i:arr) {
//				System.out.print(i+ "  ");
//			}
//			bubbleSort(arr);
			
//			insertionSort(arr);
			quickSort(arr,0,arr.length-1);
			
			selectionSort(arr);
			System.out.println("Sorted Array elements: ");
			for(int i:arr) {
				System.out.print(i+ "  ");
			}
		}

	}

}
